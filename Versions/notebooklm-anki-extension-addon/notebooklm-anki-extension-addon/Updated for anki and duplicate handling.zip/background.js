// background.js - v9.2 (Better duplicate handling)

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "sendBatchToAnki") {
    
    const PARENT_DECK = "NotebookLM";
    const SUB_DECK_NAME = request.deckTitle || "Default Notebook";
    const TARGET_DECK = `${PARENT_DECK}::${SUB_DECK_NAME}`;
    const NOTE_TYPE = "NotebookLM Markdown";

    const notes = request.batchData.map(card => {
      return {
        "deckName": TARGET_DECK,
        "modelName": NOTE_TYPE,
        "fields": {
          "Question":     card.question,
          "Hint":         card.hint,
          "ArchDiagram":  "",
          
          "Option1":      card.option1,
          "Rationale1":   card.rationale1,
          "Flag1":        card.flag1,
          
          "Option2":      card.option2,
          "Flag2":        card.flag2,
          "Rationale2":   card.rationale2,
          
          "Option3":      card.option3,
          "Flag3":        card.flag3,
          "Rationale3":   card.rationale3,
          
          "Option4":      card.option4,
          "Flag4":        card.flag4,
          "Rationale4":   card.rationale4
        },
        "tags": ["notebooklm_export"]
      };
    });

    // Create deck first
    fetch('http://127.0.0.1:8765', {
      method: 'POST',
      body: JSON.stringify({
        "action": "createDeck",
        "version": 6,
        "params": { "deck": TARGET_DECK }
      })
    })
    .then(() => {
      // Add notes with allowDuplicate option
      return fetch('http://127.0.0.1:8765', {
        method: 'POST',
        body: JSON.stringify({
          "action": "addNotes",
          "version": 6,
          "params": {
            "notes": notes,
            "options": {
              "allowDuplicate": true,       // ← allows re-exporting
              "duplicateScope": "deck"      // only check inside this deck
            }
          }
        })
      });
    })
    .then(response => response.json())
    .then(data => {
      if (data.error) {
        console.error("AnkiConnect Error", data.error);
        sendResponse({ success: false, error: "Anki Error: " + data.error });
        return;
      }

      const results = data.result || [];
      const successCount = results.filter(id => id !== null).length;
      const duplicateCount = results.filter(id => id === null).length;

      if (successCount === 0 && notes.length > 0) {
        // Everything was a duplicate
        sendResponse({
          success: true,
          count: 0,
          duplicates: duplicateCount,
          message: `All ${duplicateCount} cards already exist in Anki`
        });
      } else {
        sendResponse({
          success: true,
          count: successCount,
          duplicates: duplicateCount
        });
      }
    })
    .catch(err => {
      console.error(err);
      sendResponse({ success: false, error: "Connection Failed: Is Anki open + AnkiConnect running?" });
    });

    return true; // keep the message channel open
  }
});